/**
 * Copyright (C) 2015 Couchbase, Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALING
 * IN THE SOFTWARE.
 */
package com.couchbase.handson.n1ql;

import static com.couchbase.client.java.query.Select.*;
import static com.couchbase.client.java.query.dsl.Expression.*;
import static com.couchbase.client.java.query.dsl.Functions.tostring;
import static com.couchbase.client.java.query.dsl.Sort.asc;

import com.couchbase.client.core.logging.CouchbaseLogger;
import com.couchbase.client.core.logging.CouchbaseLoggerFactory;
import com.couchbase.client.java.Bucket;
import com.couchbase.client.java.CouchbaseCluster;
import com.couchbase.client.java.document.json.JsonObject;
import com.couchbase.client.java.env.CouchbaseEnvironment;
import com.couchbase.client.java.env.DefaultCouchbaseEnvironment;
import com.couchbase.client.java.query.Query;
import com.couchbase.client.java.query.QueryResult;
import com.couchbase.client.java.query.Statement;
import com.couchbase.client.java.query.dsl.Functions;
import com.couchbase.client.java.query.dsl.Sort;

public class Main {

    private static final String COUCHBASE_IP = "127.0.0.1";

    private static final CouchbaseLogger LOGGER = CouchbaseLoggerFactory.getInstance(Main.class);

    public static void main(String[] args) {
        LOGGER.info("Starting Application");
        CouchbaseEnvironment env = DefaultCouchbaseEnvironment.builder()
                .queryEnabled(true)
                .build();

        CouchbaseCluster cluster = CouchbaseCluster.create(env, COUCHBASE_IP);
        try {
            Bucket bucket = cluster.openBucket("beer-sample");

            querySimple(bucket);
            queryPredicate(bucket);
            queryJoin(bucket);
        } finally {
            cluster.disconnect();
        }
    }

    private static void querySimple(Bucket bucket) {
        Query query = null; //TODO simple query with string statement

        try {
            QueryResult result = null; //TODO execute

            if (result.finalSuccess()) {
                System.out.println("Simple query succeeded : " + result.allRows());
            } else {
                System.err.println("Simple query failed ");
                for (JsonObject error : result.errors()) {
                    System.err.println(error);
                }
            }
        } catch (Exception e) {
            LOGGER.error("Error while issuing simple query", e);
        }
    }

    private static void queryPredicate(Bucket bucket) {
        //we use the DSL this time
        //we static imported Select.* and Expression.*
        Statement selectPredicate = null; //TODO select with WHERE using DSL

        Query query = null; //TODO simple query

        try {
            QueryResult result = null; //TODO execute

            if (result.finalSuccess()) {
                System.out.println("Predicate query succeeded : " + result.allRows());
            } else {
                System.err.println("Predicate query failed ");
                for (JsonObject error : result.errors()) {
                    System.err.println(error);
                }
            }
        } catch (Exception e) {
            LOGGER.error("Error while issuing predicate query", e);
        }
    }
    private static void queryJoin(Bucket bucket) {
        Statement joinPredicate = null; //TODO join query using DSL?

        Query query = null; //TODO simple query

        try {
            QueryResult result = null; //TODO execute

            if (result.finalSuccess()) {
                System.out.println("Join query succeeded : " + result.allRows());
            } else {
                System.err.println("Join query failed ");
                for (JsonObject error : result.errors()) {
                    System.err.println(error);
                }
            }
        } catch (Exception e) {
            LOGGER.error("Error while issuing join query", e);
        }
    }
}
