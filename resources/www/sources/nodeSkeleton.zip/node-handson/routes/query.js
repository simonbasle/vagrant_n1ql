var express = require('express');
var couchbase = require('couchbase');
var router = express.Router();
var myCluster = new couchbase.Cluster('192.168.1.149:8091');
var N1qlQuery = couchbase.N1qlQuery;
var myBucket = myCluster.openBucket("beer-sample");
myBucket.enableN1ql('192.168.1.149:8093');

var query1 = 'ORDER BY name LIMIT 10';
var query2 = 'ORDER BY name LIMIT 10';
var query3 = 'JOIN';


router.get('/', function(req, resp, next) {
    doquery(req, resp, next, query1);
});

router.get('/1', function(req, resp, next) {
    doquery(req, resp, next, query1);
});

router.get('/2', function(req, resp, next) {
    doquery(req, resp, next, query2);
});

router.get('/3', function(req, resp, next) {
    doquery(req, resp, next, query3);
});

function doquery(req, resp, next, statement) {
    var query = N1qlQuery.fromString(statement);
    console.log(query);
    myBucket.query(query, function(err, queryRes) {
        if (err) {
            console.log('query failed', err);
            resp.send(err.message);
            return;
        }
        console.log('success!', queryRes);
        resp.send(queryRes);
    });
}

module.exports = router;
