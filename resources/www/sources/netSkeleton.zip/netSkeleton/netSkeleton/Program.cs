﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Couchbase;
using Couchbase.Configuration.Client;
using Couchbase.Configuration.Client.Providers;
using Couchbase.Core;
using Couchbase.N1QL;

namespace netSkeleton
{
    class Program
    {
        static void Main(string[] args)
        {
            ClusterHelper.Initialize("couchbaseClients/couchbase");
            IBucket beerBucket = ClusterHelper.GetBucket("beer-sample");

            //try to do a simple select of 10 name of beers (in alphabetical order) from the beer-sample
            //TODO replace the nulls below
            string simpleStatement = null;
            QueryRequest simple = null;
            IQueryResult<dynamic> simpleResult = null; //execute
            Dump(simpleResult);

            Console.WriteLine("Press any key to continue");
            Console.ReadKey();

            //now you must have seen there are false positives (breweries).
            //Try to use a WHERE clause to really only show beers.
            //TODO replace the nulls below
            string predicateStatement = null;
            QueryRequest predicate = null;
            IQueryResult<dynamic> predicateResult = null;
            Dump(predicateResult);

            Console.WriteLine("Press any key to continue");
            Console.ReadKey();

            //finally, try a more complicated join. For example, try to get the beers from my favorite breweries.
            //They are in default bucket with keys like "favorite_brewery_id"...
            //TODO replace the nulls below
            string joinStatement = null;
            QueryRequest join = null;
            IQueryResult<dynamic> joinResult = null;
            Dump(joinResult);

            ClusterHelper.Close();
            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
        }

        private static void Dump(IQueryResult<object> result)
        {
            Console.WriteLine("Result:");
            Console.WriteLine(result.Status);
            if (result.Success)
            {
                result.Rows.ForEach(r => Console.WriteLine(r));
            }
            else
            {
                result.Errors.ForEach(e => Console.WriteLine(e.Code + " " + e.Message));
            }
        }
    }
}
